#!/bin/bash

java -cp 'anon-enterprise-only.jar:lib/*' org.anon.enterprise.runner.AnonServerRunner %1