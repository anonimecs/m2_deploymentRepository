#!/bin/bash

java -cp 'anon-enterprise-only.jar:lib/*' org.anon.enterprise.runner.AnonStandaloneRunner %1